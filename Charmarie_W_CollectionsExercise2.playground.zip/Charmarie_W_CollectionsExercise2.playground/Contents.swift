import UIKit

// included in each genre is my favorite actor/character in each of the movies.
var movies = [Int] ()

movies.append(28)

var horror: [String] = ["Ed Warren: The Conjouring", "Polite Stranger: The Purge"]

var comedy: [String] = ["Adam Sandler: 50 First Dates", "Johnny Knoxville: Grandpa"]

comedy.append("Michael Jordan: Space Jam")

var action: [String] = ["Chris Hemsworth: Extraction", "Chris Kyle: Sniper", "Emma Roberts: The Hunt"]

action.append("Dave Bautista: My Spy")

for item in horror{
    print(item)
}

for item in comedy{
    print(item)
}

for item in action{
    print(item)
}
